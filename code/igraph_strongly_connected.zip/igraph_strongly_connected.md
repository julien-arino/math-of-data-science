# Some examples of (connected?) graphs

There are a few very interesting datasets available online. We start with something from a collection from Stanford University, see [here](https://snap.stanford.edu/data/). There are relatively large graphs, so will give us the opportunity to explore what happens when the graphs are not just a few vertices.

Let us start with something small: [here](https://snap.stanford.edu/data/ego-Facebook.html). This dataset consists of 'circles' (or 'friends lists') from Facebook. Facebook data was collected from survey participants using this Facebook app. The dataset includes node features (profiles), circles, and ego networks.

When you read the description, you notice right away that the notion of connectedness is embedded in the graph description: the acronym WCC means *weakly connected components*, SCC being, of course, *strongly connected components*.

Downloading the data, we see that there are a number of files, each prefixed by a number. From the description, these files are as follows (for a given `nodeId`):

- nodeId.edges : The edges in the ego network for the node 'nodeId'. Edges are undirected for facebook, and directed (a follows b) for twitter and gplus. The 'ego' node does not appear, but it is assumed that they follow every node id that appears in this file.
- nodeId.circles : The set of circles for the ego node. Each line contains one circle, consisting of a series of node ids. The first entry in each line is the name of the circle.
- nodeId.feat : The features for each of the nodes that appears in the edge file.
- nodeId.egofeat : The features for the ego user.
- nodeId.featnames : The names of each of the feature dimensions. Features are '1' if the user has this property in their profile, and '0' otherwise. This file has been anonymized for facebook users, since the names of the features would reveal private data.

Let us take a look at `nodeId=0`. The most important files (for now) are `0.circles` and `0.edges`. We take a quick look at the text files themselves and remark that `0.circles` seems to be tsv (tab separated values) files, while the entries in `0.edges` are separated by spaces. Also, the data starts from the first row.


```R
circles = read.csv("0.circles", sep = "\t", header = FALSE)
edges = read.csv("0.edges", sep = " ", header = FALSE)
```


```R
circles
head(edges)
```


<table class="dataframe">
<caption>A data.frame: 32 × 21</caption>
<thead>
	<tr><th scope=col>V1</th><th scope=col>V2</th><th scope=col>V3</th><th scope=col>V4</th><th scope=col>V5</th><th scope=col>V6</th><th scope=col>V7</th><th scope=col>V8</th><th scope=col>V9</th><th scope=col>V10</th><th scope=col>⋯</th><th scope=col>V12</th><th scope=col>V13</th><th scope=col>V14</th><th scope=col>V15</th><th scope=col>V16</th><th scope=col>V17</th><th scope=col>V18</th><th scope=col>V19</th><th scope=col>V20</th><th scope=col>V21</th></tr>
	<tr><th scope=col>&lt;chr&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>⋯</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><td>circle0 </td><td> 71</td><td>215</td><td> 54</td><td> 61</td><td>298</td><td>229</td><td> 81</td><td>253</td><td>193</td><td>⋯</td><td>264</td><td> 29</td><td>132</td><td>110</td><td>163</td><td>259</td><td>183</td><td>334</td><td>245</td><td>222</td></tr>
	<tr><td>circle1 </td><td>173</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td>⋯</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle2 </td><td>155</td><td> 99</td><td>327</td><td>140</td><td>116</td><td>147</td><td>144</td><td>150</td><td>270</td><td>⋯</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle3 </td><td> 51</td><td> 83</td><td>237</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td>⋯</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle4 </td><td>125</td><td>344</td><td>295</td><td>257</td><td> 55</td><td>122</td><td>223</td><td> 59</td><td>268</td><td>⋯</td><td> 84</td><td>156</td><td>258</td><td>236</td><td>250</td><td>239</td><td> 69</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle5 </td><td> 23</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td>⋯</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle6 </td><td>337</td><td>289</td><td> 93</td><td> 17</td><td>111</td><td> 52</td><td>137</td><td>343</td><td>192</td><td>⋯</td><td>326</td><td>310</td><td>214</td><td> 32</td><td>115</td><td>321</td><td>209</td><td>312</td><td> 41</td><td> 20</td></tr>
	<tr><td>circle7 </td><td>225</td><td> 46</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td>⋯</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle8 </td><td>282</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td>⋯</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle9 </td><td>336</td><td>204</td><td> 74</td><td>206</td><td>292</td><td>146</td><td>154</td><td>164</td><td>279</td><td>⋯</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle10</td><td> 42</td><td> 14</td><td>216</td><td>  2</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td>⋯</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle11</td><td>324</td><td>265</td><td> 54</td><td>161</td><td>298</td><td> 76</td><td>165</td><td>199</td><td>203</td><td>⋯</td><td> 66</td><td>113</td><td> 97</td><td>252</td><td>313</td><td>238</td><td>158</td><td>240</td><td>331</td><td>332</td></tr>
	<tr><td>134     </td><td>218</td><td>118</td><td>235</td><td>311</td><td>151</td><td>308</td><td>212</td><td> 70</td><td>211</td><td>⋯</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle12</td><td>278</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td>⋯</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle13</td><td>138</td><td>131</td><td> 68</td><td>143</td><td> 86</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td>⋯</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle14</td><td>175</td><td>227</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td>⋯</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle15</td><td>108</td><td>208</td><td>251</td><td>125</td><td>325</td><td>176</td><td>133</td><td>276</td><td>198</td><td>⋯</td><td>288</td><td>316</td><td> 96</td><td>246</td><td>347</td><td>121</td><td>  7</td><td>  3</td><td>170</td><td>323</td></tr>
	<tr><td>56      </td><td>338</td><td> 23</td><td>109</td><td>141</td><td> 67</td><td>345</td><td> 55</td><td>114</td><td>122</td><td>⋯</td><td>304</td><td>318</td><td> 65</td><td> 15</td><td> 45</td><td>317</td><td>322</td><td> 26</td><td> 31</td><td>168</td></tr>
	<tr><td>124     </td><td>285</td><td>255</td><td>129</td><td> 40</td><td>172</td><td>274</td><td> 95</td><td>207</td><td>128</td><td>⋯</td><td>233</td><td>  1</td><td>294</td><td>280</td><td>224</td><td>269</td><td>256</td><td> 60</td><td>328</td><td>189</td></tr>
	<tr><td>146     </td><td> 77</td><td>196</td><td> 64</td><td>286</td><td> 89</td><td> 22</td><td> 39</td><td>190</td><td>281</td><td>⋯</td><td> 38</td><td>213</td><td>135</td><td>197</td><td>291</td><td> 21</td><td>315</td><td>261</td><td> 47</td><td> 36</td></tr>
	<tr><td>186     </td><td>169</td><td>342</td><td> 49</td><td>  9</td><td> 16</td><td>185</td><td>219</td><td>123</td><td> 72</td><td>⋯</td><td>103</td><td>157</td><td>277</td><td>105</td><td>139</td><td>148</td><td>248</td><td>341</td><td> 62</td><td> 98</td></tr>
	<tr><td>63      </td><td>297</td><td>242</td><td> 10</td><td>152</td><td>236</td><td>308</td><td> 82</td><td> 87</td><td>136</td><td>⋯</td><td>183</td><td>247</td><td>290</td><td>303</td><td>319</td><td>  6</td><td>314</td><td>104</td><td>127</td><td> 25</td></tr>
	<tr><td>69      </td><td>171</td><td>119</td><td> 79</td><td>340</td><td>301</td><td>188</td><td>142</td><td> NA</td><td> NA</td><td>⋯</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle16</td><td>251</td><td> 94</td><td>330</td><td>  5</td><td> 34</td><td>299</td><td>254</td><td> 24</td><td>180</td><td>⋯</td><td>281</td><td>101</td><td>266</td><td>135</td><td>197</td><td>173</td><td> 36</td><td>  9</td><td> 85</td><td> 57</td></tr>
	<tr><td>37      </td><td>258</td><td>309</td><td> 80</td><td>139</td><td>202</td><td>187</td><td>249</td><td> 58</td><td>127</td><td>⋯</td><td> 92</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle17</td><td> 90</td><td> 52</td><td>172</td><td>126</td><td>294</td><td>179</td><td>145</td><td>105</td><td>210</td><td>⋯</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle18</td><td>177</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td>⋯</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle19</td><td> 93</td><td> 33</td><td>333</td><td> 17</td><td>137</td><td> 44</td><td>343</td><td>326</td><td>214</td><td>⋯</td><td>312</td><td> 41</td><td> 20</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle20</td><td>244</td><td>282</td><td>262</td><td>293</td><td>220</td><td>174</td><td> NA</td><td> NA</td><td> NA</td><td>⋯</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle21</td><td> 12</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td>⋯</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle22</td><td>267</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td>⋯</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
	<tr><td>circle23</td><td> 28</td><td>149</td><td>162</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td>⋯</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td><td> NA</td></tr>
</tbody>
</table>




<table class="dataframe">
<caption>A data.frame: 6 × 2</caption>
<thead>
	<tr><th></th><th scope=col>V1</th><th scope=col>V2</th></tr>
	<tr><th></th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>236</td><td>186</td></tr>
	<tr><th scope=row>2</th><td>122</td><td>285</td></tr>
	<tr><th scope=row>3</th><td> 24</td><td>346</td></tr>
	<tr><th scope=row>4</th><td>271</td><td>304</td></tr>
	<tr><th scope=row>5</th><td>176</td><td>  9</td></tr>
	<tr><th scope=row>6</th><td>130</td><td>329</td></tr>
</tbody>
</table>



`edges` went fine, but for `circles`, we have a problem: despite the fact that all entries in circle15, for instance, seem to be on the same line in the file, they are read as multiple lines. Let us confirm.


```R
dim(circles)
```


<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>32</li><li>21</li></ol>



Yup, clearly a problem here, there should be way more than 21 columns! Let us try something a bit more evolved: we read line by line and process this. We make a little function (slightly adapted from one [here](https://stackoverflow.com/questions/12626637/read-a-text-file-in-r-line-by-line)).


```R
processFile = function(filepath) {
    con = file(filepath, "r")
    OUT = list()
    i = 1
    while ( TRUE ) {
        line = readLines(con, n = 1)
        if ( length(line) == 0 ) {
            break
        }
        OUT[[i]] = line
        i = i+1
    }
    close(con)
    return(OUT)
}

circles = processFile("0.circles")
```


```R
circles[[1]]
```


'circle0\t71\t215\t54\t61\t298\t229\t81\t253\t193\t97\t264\t29\t132\t110\t163\t259\t183\t334\t245\t222'


Looks good. Let us process this to make things a bit easier to use.


```R
for (i in 1:length(circles)) {
    circles[[i]] = gsub("\t", ",", circles[[i]])
}
circles[[1]]
```


'circle0,71,215,54,61,298,229,81,253,193,97,264,29,132,110,163,259,183,334,245,222'


This one's okay, now let us make the graph, using `graph_from_edgelist` (`from_edgelist` for short); see help [here](https://igraph.org/r/html/latest/graph_from_edgelist.html). Data description says the facebook graph is undirected, so we use that option.


```R
library(igraph)
G = graph_from_edgelist(as.matrix(edges), directed = FALSE)
plot(G)
```


    
![png](output_11_0.png)
    



```R
gorder(G)
```


347



```R
C = components(G)
writeLines(paste0("Number of components: ", C$no))
C$csize
```

    Number of components: 19



<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>324</li><li>1</li><li>1</li><li>1</li><li>1</li><li>2</li><li>1</li><li>1</li><li>1</li><li>3</li><li>1</li><li>1</li><li>1</li><li>1</li><li>2</li><li>2</li><li>1</li><li>1</li><li>1</li></ol>



Let us keep only the vertices in the largest connected component (the one with 324 vertices). We look at the membership information.


```R
groups(C)
```


<dl>
	<dt>$`1`</dt>
		<dd><style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>1</li><li>2</li><li>3</li><li>4</li><li>5</li><li>6</li><li>7</li><li>8</li><li>9</li><li>10</li><li>13</li><li>14</li><li>16</li><li>17</li><li>19</li><li>20</li><li>21</li><li>22</li><li>23</li><li>24</li><li>25</li><li>26</li><li>27</li><li>28</li><li>29</li><li>30</li><li>31</li><li>32</li><li>34</li><li>35</li><li>36</li><li>38</li><li>39</li><li>40</li><li>41</li><li>44</li><li>45</li><li>46</li><li>47</li><li>48</li><li>49</li><li>50</li><li>51</li><li>52</li><li>53</li><li>54</li><li>55</li><li>56</li><li>57</li><li>58</li><li>59</li><li>60</li><li>61</li><li>62</li><li>63</li><li>64</li><li>65</li><li>66</li><li>67</li><li>68</li><li>69</li><li>70</li><li>71</li><li>72</li><li>73</li><li>75</li><li>76</li><li>77</li><li>78</li><li>79</li><li>80</li><li>81</li><li>82</li><li>83</li><li>84</li><li>85</li><li>86</li><li>87</li><li>88</li><li>89</li><li>91</li><li>92</li><li>93</li><li>94</li><li>95</li><li>96</li><li>97</li><li>98</li><li>99</li><li>100</li><li>101</li><li>102</li><li>103</li><li>104</li><li>105</li><li>106</li><li>107</li><li>108</li><li>109</li><li>110</li><li>111</li><li>112</li><li>113</li><li>115</li><li>116</li><li>117</li><li>118</li><li>119</li><li>120</li><li>121</li><li>122</li><li>123</li><li>124</li><li>125</li><li>126</li><li>127</li><li>128</li><li>129</li><li>130</li><li>131</li><li>132</li><li>133</li><li>134</li><li>135</li><li>136</li><li>137</li><li>138</li><li>139</li><li>140</li><li>141</li><li>142</li><li>143</li><li>144</li><li>146</li><li>147</li><li>148</li><li>149</li><li>150</li><li>151</li><li>152</li><li>153</li><li>154</li><li>155</li><li>156</li><li>157</li><li>158</li><li>159</li><li>160</li><li>161</li><li>162</li><li>163</li><li>164</li><li>165</li><li>166</li><li>167</li><li>168</li><li>169</li><li>170</li><li>171</li><li>172</li><li>173</li><li>174</li><li>175</li><li>176</li><li>177</li><li>178</li><li>180</li><li>181</li><li>182</li><li>183</li><li>184</li><li>185</li><li>186</li><li>187</li><li>188</li><li>189</li><li>190</li><li>191</li><li>192</li><li>193</li><li>194</li><li>195</li><li>196</li><li>197</li><li>198</li><li>199</li><li>200</li><li>201</li><li>202</li><li>203</li><li>204</li><li>205</li><li>206</li><li>207</li><li>208</li><li>211</li><li>212</li><li>213</li><li>214</li><li>216</li><li>217</li><li>218</li><li>219</li><li>220</li><li>221</li><li>222</li><li>223</li><li>224</li><li>225</li><li>226</li><li>227</li><li>228</li><li>229</li><li>230</li><li>231</li><li>232</li><li>234</li><li>235</li><li>236</li><li>237</li><li>238</li><li>239</li><li>240</li><li>241</li><li>242</li><li>243</li><li>245</li><li>246</li><li>247</li><li>248</li><li>249</li><li>250</li><li>251</li><li>252</li><li>253</li><li>254</li><li>255</li><li>257</li><li>258</li><li>259</li><li>260</li><li>261</li><li>262</li><li>263</li><li>264</li><li>265</li><li>266</li><li>267</li><li>268</li><li>269</li><li>270</li><li>271</li><li>272</li><li>273</li><li>274</li><li>275</li><li>276</li><li>277</li><li>278</li><li>279</li><li>280</li><li>281</li><li>283</li><li>284</li><li>285</li><li>286</li><li>288</li><li>289</li><li>290</li><li>291</li><li>293</li><li>294</li><li>295</li><li>296</li><li>297</li><li>298</li><li>299</li><li>300</li><li>301</li><li>302</li><li>303</li><li>304</li><li>305</li><li>306</li><li>307</li><li>308</li><li>309</li><li>310</li><li>311</li><li>312</li><li>313</li><li>314</li><li>315</li><li>316</li><li>317</li><li>318</li><li>319</li><li>320</li><li>321</li><li>322</li><li>323</li><li>324</li><li>325</li><li>326</li><li>327</li><li>328</li><li>329</li><li>330</li><li>331</li><li>332</li><li>333</li><li>334</li><li>336</li><li>337</li><li>338</li><li>339</li><li>340</li><li>341</li><li>342</li><li>343</li><li>344</li><li>345</li><li>346</li><li>347</li></ol>
</dd>
	<dt>$`2`</dt>
		<dd>11</dd>
	<dt>$`3`</dt>
		<dd>12</dd>
	<dt>$`4`</dt>
		<dd>15</dd>
	<dt>$`5`</dt>
		<dd>18</dd>
	<dt>$`6`</dt>
		<dd><style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>33</li><li>42</li></ol>
</dd>
	<dt>$`7`</dt>
		<dd>37</dd>
	<dt>$`8`</dt>
		<dd>43</dd>
	<dt>$`9`</dt>
		<dd>74</dd>
	<dt>$`10`</dt>
		<dd><style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>90</li><li>145</li><li>179</li></ol>
</dd>
	<dt>$`11`</dt>
		<dd>114</dd>
	<dt>$`12`</dt>
		<dd>209</dd>
	<dt>$`13`</dt>
		<dd>210</dd>
	<dt>$`14`</dt>
		<dd>215</dd>
	<dt>$`15`</dt>
		<dd><style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>233</li><li>256</li></ol>
</dd>
	<dt>$`16`</dt>
		<dd><style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>244</li><li>282</li></ol>
</dd>
	<dt>$`17`</dt>
		<dd>287</dd>
	<dt>$`18`</dt>
		<dd>292</dd>
	<dt>$`19`</dt>
		<dd>335</dd>
</dl>



We need to be able to find what component is the largest. To do that, we simply seek the group with the most elements.


```R
idx_large = which(unlist(lapply(groups(C), length) == max(C$csize)))
idx_large
```


<strong>1:</strong> 1



```R
G_c = induced_subgraph(G, groups(C)[[idx_large]])
plot(G_c)
```


    
![png](output_18_0.png)
    


# Another example

To see how efficacious component computation goes, let us look at [this dataset](https://snap.stanford.edu/data/twitch_gamers.html). We just load one file of the three in the zip file. The file is quite big, so we do not unzip it and just load it as is. The next operation might take a while.


```R
twitch <- read.csv(unz("large_twitch_edges.csv.zip", "large_twitch_edges.csv"))
```


```R
head(twitch)
dim(twitch)
```


<table class="dataframe">
<caption>A data.frame: 6 × 2</caption>
<thead>
	<tr><th></th><th scope=col>numeric_id_1</th><th scope=col>numeric_id_2</th></tr>
	<tr><th></th><th scope=col>&lt;int&gt;</th><th scope=col>&lt;int&gt;</th></tr>
</thead>
<tbody>
	<tr><th scope=row>1</th><td>98343</td><td>141493</td></tr>
	<tr><th scope=row>2</th><td>98343</td><td> 58736</td></tr>
	<tr><th scope=row>3</th><td>98343</td><td>140703</td></tr>
	<tr><th scope=row>4</th><td>98343</td><td>151401</td></tr>
	<tr><th scope=row>5</th><td>98343</td><td>157118</td></tr>
	<tr><th scope=row>6</th><td>98343</td><td>125430</td></tr>
</tbody>
</table>




<style>
.list-inline {list-style: none; margin:0; padding: 0}
.list-inline>li {display: inline-block}
.list-inline>li:not(:last-child)::after {content: "\00b7"; padding: 0 .5ex}
</style>
<ol class=list-inline><li>6797557</li><li>2</li></ol>



Ah, that's bigger! We'll load but not try to plot..


```R
#G = graph_from_edgelist(as.matrix(twitch), directed = FALSE)
```

Actually, strike that: tried this, it's too big for the machines at syzygy.ca, it seems. So I ran this on one of the beefy machines of my home cluster and saved the result as an `Rds` file, which I will distribute. Actually, doing this I realised that perhaps the problem was that the data contains reference to vertices labelled 0, and taking them out was important. Let's see if that works here.


```R
# The following version of which returns array (matrix) indices of the found 
# entries, because the zeros can be in both columns of twitch. But then we only need 
# the rows in that index set.
idx_zero = which(twitch == 0, arr.ind = TRUE)[1]
twitch = twitch[setdiff(1:dim(twitch)[1], idx_zero),]
```


```R
G = graph_from_edgelist(as.matrix(twitch), directed = FALSE)
```

OK, no, still not doing it. Probably too much RAM needed for intermediate operations. That is not going to work! I end up with a 75 MB file.
